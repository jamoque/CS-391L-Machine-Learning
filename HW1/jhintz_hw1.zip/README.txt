Name: 		Jeremy Hintz
UT EID:		jjh2595
CS Login: 	jhintz

This project was first attempted in Python but converted to MATLAB. The code for both can be found in this submission.

In order to run the MATLAB version, run the hw1Main.m file with desired parameters, which are explained in the comments of the function itself.